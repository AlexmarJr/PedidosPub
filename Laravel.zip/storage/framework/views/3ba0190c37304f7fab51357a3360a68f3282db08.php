<HTML>
        <HEAD>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <TITLE>Consulta de Pedidos (Administrador)</TITLE>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
        </HEAD>
        <BODY style="background-color: gray">
          <div style="padding-bottom: 20px">
          <header>
              <nav class="navbar navbar-expand-lg navbar-light" style="background-color: white">
                  <img src="img/book.png" style="width: 2%">
                 
                
                  <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
                    <ul class="navbar-nav mr-auto" style="padding-left: 50px">
                        <li class="nav-item active">
                            <a class="nav-link" href="<?php echo e(route('index')); ?>">Realizar Pedido&nbsp;&nbsp;&nbsp;|<span class="sr-only"></span></a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="<?php echo e(route('search')); ?>">Consultar Pedido&nbsp;&nbsp;&nbsp;|<span class="sr-only">(página atual)</span></a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="<?php echo e(route('searchEnviados')); ?>">Historico de Pedidos<span class="sr-only"></span></a>
                        </li>
                    </ul>
                    <div class="active" style="margin-right:15px"> 
                        <button type="button" class="btn btn-dark float-right" onclick="wipe()">Limpar e Armazenar Todos Pedidos</button>
                    </div>
                  </div>
                  <a class="nav-link" href="<?php echo e(route('logoff')); ?>" style="background-color:red;color:white;border-radius: 25%">Logoff<span class="sr-only"></span></a>
                </nav>
          </header>
        </div>
              <div class="container float-left" style="background-color: white;margin-top: 20px;margin-left: 25px;border-radius: 2%">
                  <table class="table">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Data</th>
                        <th scope="col">Congregação</th>
                        <th scope="col">Publicação</th>
                        <th scope="col">Idioma</th>
                        <th scope="col">Quantidade</th>
                        <th scope="col">Ações</th>
                      </tr>
                      <?php $__currentLoopData = $publ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td scope="row"><?php echo e($value->id); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($value->created_at)->format('d/m/Y')); ?></td>
                        <td><?php echo e($value->congregacao); ?></td>
                        <td><?php echo e($value->name); ?></td>
                        <td><?php echo e($value->idioma); ?></td>
                        <td><?php echo e($value->quant); ?></td>
                        <?php if($value->status == '0'): ?><td><a href="<?php echo e(route('change.admin', $value->id)); ?>" class="btn btn-success">Concluido</a></td> <?php else: ?> <td>-----</td> <?php endif; ?>
                        <td><a href="<?php echo e(route('delete.admin', $value->id)); ?>" class="btn btn-danger">Excluir</a></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
              </div>
          
        </BODY>
        <script>
        function test(){
            var x = document.getElementById("quant").value;
            alert(x);
        }

        function wipe(){
            Swal.fire({
                title: 'Voçê Tem Certeza?',
                text: "Voçê ira armazenar todos os pedidos",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                cancelButtonText: 'Não',
                confirmButtonText: 'Sim'
                }).then((result) => {
                if (result.value) {
                    Swal.fire(
                    'Pronto!',
                    'Todos Pedidos Foram Armazenados',
                    'success'
                    )
                }
            })
        }
        </script>
      </HTML><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/admin.blade.php ENDPATH**/ ?>