<HTML>
  <HEAD>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <TITLE>Pedidos Publicações</TITLE>
  </HEAD>
  <BODY style="background-color: gray">
    <div style="padding-bottom: 20px">
    <header>
        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: white">
            <img src="img/book.png" style="width: 2%">
           
          
            <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
              <ul class="navbar-nav mr-auto" style="padding-left: 50px">
              <?php if($userName != 'admin'): ?>
              <li class="nav-item active">
                  <p class="nav-link">Realizar Pedido&nbsp;&nbsp;&nbsp;|<span class="sr-only">(página atual)</span></p>
                </li>
              <?php endif; ?>
              <?php if($userName == 'admin'): ?>
                <li class="nav-item active">
                  <a class="nav-link" href="<?php echo e(route('index')); ?>">Realizar Pedido&nbsp;&nbsp;&nbsp;|<span class="sr-only">(página atual)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('search')); ?>">Consultar Pedido&nbsp;&nbsp;&nbsp;|<span class="sr-only"></span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('searchEnviados')); ?>">Historico de Pedidos<span class="sr-only"></span></a>
                </li>
                <?php endif; ?>
              </ul>
            </div>
            <a class="nav-link" href="<?php echo e(route('logoff')); ?>" style="background-color:red;color:white;border-radius: 25%">Logoff<span class="sr-only"></span></a>
          </nav>
    </header>
  </div>
  <form action="<?php echo e(route('store')); ?>" method="post" autocomplete="off" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <?php if(isset($head)): ?>
  <input type="hidden" name="id" value="<?php echo e($head->id); ?>">
  <?php endif; ?>
        <div class="row" style="margin-left: 10px;">
            <div class="col-sm-3">
              <select class="form-control" required id='selectPub' name='selectPub'> 
                <option value="" disabled selected hidden>Publicação</option>
                <option disabled style="color: red">Biblia</option>
                <option value="Tradução do Novo Mundo da Biblia Sagrada"  <?php if(isset($head) && ($head->name == 'Tradução do Novo Mundo da Biblia Sagrada')): ?> selected <?php endif; ?> >Tradução do Novo Mundo da Biblia Sagrada</option>
                <option value="Tradução do Novo Mundo da Biblia Sagrada(Edição Pequena)" <?php if(isset($head) && ($head->name == 'Tradução do Novo Mundo da Biblia Sagrada(Edição Pequena)')): ?> selected <?php endif; ?> >Tradução do Novo Mundo da Biblia Sagrada>Tradução do Novo Mundo da Biblia Sagrada(Edição Pequena)</option>
                <option disabled style="color: red">Livros</option>
                <option value="Dê Testemunho Cabal sobre o Reino de Deus"  <?php if(isset($head) && ($head->name == 'Dê Testemunho Cabal sobre o Reino de Deus')): ?> selected <?php endif; ?>  >Dê Testemunho Cabal sobre o Reino de Deus</option>
                <option value="Venha ser Meu Seguidor" <?php if(isset($head) && ($head->name == 'Venha ser Meu Seguidor')): ?> selected <?php endif; ?> >Venha ser Meu Seguidor</option>
                <option value="Adoração Pura de Jeová é Restaurada" <?php if(isset($head) && ($head->name == 'Adoração Pura de Jeová é Restaurada')): ?> selected <?php endif; ?> >Adoração Pura de Jeová é Restaurada</option>
                <option value="Achegue-se" <?php if(isset($head) && ($head->name == 'Achegue-se')): ?> selected <?php endif; ?>>Achegue-se</option>
                <option value="Aprenda com as Histórias da Biblia" <?php if(isset($head) && ($head->name == 'Aprenda com as Histórias da Biblia')): ?> selected <?php endif; ?>>Aprenda com as Histórias da Biblia</option>
                <option value="Aprenda com o Grande Instrutor" <?php if(isset($head) && ($head->name == 'Aprenda com o Grande Instrutor')): ?> selected <?php endif; ?>>Aprenda com o Grande Instrutor</option>
                <option value="Cante de Coração a Jeová" <?php if(isset($head) && ($head->name == 'Cante de Coração a Jeová')): ?> selected <?php endif; ?>>Cante de Coração a Jeová</option>
                <option value="Os Jovens Perguntam - Respostas Práticas, Volume 1" <?php if(isset($head) && ($head->name == 'Os Jovens Perguntam - Respostas Práticas, Volume 1')): ?> selected <?php endif; ?>>Os Jovens Perguntam - Respostas Práticas, Volume 1</option>
                <option value="Os Jovens Perguntam - Respostas Práticas, Volume 2" <?php if(isset($head) && ($head->name == 'Os Jovens Perguntam - Respostas Práticas, Volume 2')): ?> selected <?php endif; ?>>Os Jovens Perguntam - Respostas Práticas, Volume 2</option>
                <option value="Cante de Coração a Jeová - Sem Pauta" <?php if(isset($head) && ($head->name == 'Cante de Coração a Jeová - Sem Pauta')): ?> selected <?php endif; ?>>Cante de Coração a Jeová - Sem Pauta</option>
                <option value="Cante de Coração a Jeová - Edição Grande" <?php if(isset($head) && ($head->name == 'Cante de Coração a Jeová - Edição Grande')): ?> selected <?php endif; ?>>Cante de Coração a Jeová - Edição Grande</option>
              </select>
            </div>

          <div class="col-sm-3">
            <select class="form-control" required id='languagePub' name='languagePub'>
              <option value="" disabled selected hidden>Idioma</option>
              <option value='PT' <?php if(isset($head) && ($head->idioma == 'PT')): ?> selected <?php endif; ?> >Português</option>
              <option value='EN' <?php if(isset($head) && ($head->idioma == 'EN')): ?> selected <?php endif; ?> >Inglês</option>
              <option value='ESP' <?php if(isset($head) && ($head->idioma == 'ESP')): ?> selected <?php endif; ?> >Espanhõl</option>
            </select>
          </div>
          
          <div class="input-group col-sm-2">
            <div class="input-group-prepend">
              <span class="input-group-text" id="inputGroup" name="inputGroup">Quantidade</span>
            </div>
              <input type="number" id="quant" name="quant" <?php if(isset($head)): ?> value="<?php echo e($head->quant); ?>" <?php endif; ?> class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" required>
              <input type="hidden" value="<?php echo e($cong); ?>" id="congregacao" name="congregacao">
              <input type="hidden" value="<?php echo e($userName); ?>" id="adminStatus" name="adminStatus">
              
          </div>

          <div class="input-group col-sm-2">
            <button type="submit" class="btn btn-light">Enviar</button>
          </div>
        </div>

        <div class="container float-left" style="background-color: white;margin-top: 20px;margin-left: 25px;border-radius: 2%">
            <table class="table">
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Publicação</th>
                  <th scope="col">Idioma</th>
                  <th scope="col">Quantidade</th>
                  <th scope="col">Ações</th>
                </tr>
                <?php $__currentLoopData = $publ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($value->congregacao == $cong): ?>
                  <tr>
                    <th scope="row"><?php echo e($value->id); ?></th>
                    <td><?php echo e($value->name); ?></td>
                    <td><?php echo e($value->idioma); ?></td>
                    <td><?php echo e($value->quant); ?></td>                                             
                    <td><a href="<?php echo e(route('delete', $value->id)); ?>" class="btn btn-danger">Excluir</a> <a href="<?php echo e(route('read', $value->id)); ?>" class="btn btn-warning">Editar</a> </td>
                  </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </table>
        </div>
    </form>
  </BODY>
  <script>
  
  </script>
</HTML><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/index.blade.php ENDPATH**/ ?>